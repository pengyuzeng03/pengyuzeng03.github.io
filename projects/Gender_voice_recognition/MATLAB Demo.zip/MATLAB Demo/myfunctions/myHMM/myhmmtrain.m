function hmm = myhmmtrain(hmm,data,emiter)
%MYHMMTRAIN - Train HMM
%
%   hmm = myhmmtrain(hmm,data)
%   hmm = myhmmtrain(hmm,data,emiter)

%% ��������Ŀ
narginchk(2,3);
nargoutchk(0,1);

%% ȱʡ��������
if nargin < 3
    emiter = 10;
end

%% ѵ��
prior0 = hmm.prior;
transmat0 = hmm.transmat;
mu0 = hmm.mu;
Sigma0 = hmm.Sigma;
weights0 = hmm.weights;
[LL, prior1, transmat1, mu1, Sigma1, mixmat1] = ...
    mhmm_em(data, prior0, transmat0, mu0, Sigma0, weights0,... 
    'max_iter', emiter, 'cov_type', 'diag', 'adj_prior', 0);

%% ����
hmm.prior = prior1;
hmm.transmat = transmat1;
hmm.mu = mu1;
hmm.Sigma = Sigma1;
hmm.weights = mixmat1;
hmm.LL = LL;

