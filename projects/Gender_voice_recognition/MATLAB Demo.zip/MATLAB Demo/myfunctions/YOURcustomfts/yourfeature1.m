function fts1 = yourfeature1(voiced,fs)
%MYFEATURE1 - Extract YOURCUSTOM feature of the signal x
%
%   fts1 = myfeature1(x,fs)

% ��һ��д�õĴ��룬��ע�ͣ��⿪������

%% 
feature=my_lpcc(voiced,fs); 
feature=feature.';
nf = size(feature,1);

fts1 =[mean(feature(1:round(nf/3),:)) mean(feature(round(nf/3)+1:round(2*nf/3),:)) mean(feature(round(2*nf/3)+1:nf,:))];
end