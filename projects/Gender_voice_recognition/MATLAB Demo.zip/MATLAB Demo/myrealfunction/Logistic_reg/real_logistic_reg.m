function re = real_logistic_reg(data,label,thetal)
%UNTITLED �˴���ʾ�йش˺�����ժҪ


X1=data;
Y1=label-ones(size(label));
result=ones(size(label));
 
m1 = size(X1,1);
Features=size(data,2); %��������
for i=1:m1
    xx=X1(i,1:Features)';
    yy=Y1(i);
    finil=1/(1+exp(-thetal* xx));
    if finil>0.5 
        result(i)=2;
    end
    if finil<=0.5 
        result(i)=1;
    end
end
re=result;
end

