function [judgement,finil] =logistics (data,thetal)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
    xx=data';
    finil=1/(1+exp(-thetal* xx));
    if finil>0.5 
        judgement =2;
    end
    if finil<=0.5 
        judgement =1;
    end
end