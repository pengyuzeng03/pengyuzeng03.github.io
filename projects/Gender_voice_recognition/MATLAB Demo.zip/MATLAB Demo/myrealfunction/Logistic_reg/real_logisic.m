[filename,pathname] = uigetfile({'*.wav';'*.mp3';'*.ogg';'*.au';'*.flac'},'Select a voice file');
if ischar(filename)&&ischar(pathname)
    [x,fs] = audioread([pathname,filename]);
    x = resample(x,8000,fs);
    fs = 8000;
    x = x/max(abs(x));
    recorder.voice = x;
    param.fs = fs;
    % 绘图
    axes(handles.axes_time);
    t = (0:length(x)-1)/fs;
    plot(t,x);xlabel('Time/s');ylabel('Amplitude');title('Speech waveform');
    % 显示栏的结论和数据清除
   
    
end

% 3 识别该信号是男声还是女声 ----------------------------------------------
function pushbuttonGoJudge_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonGoJudge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global recorder;
global param;
global control;
global classifierparam;
if isempty(recorder.voice)
    errordlg('错误！没有发现语音，请先录音或读取本地语音','错误提示');
elseif sum(control.featurechanged)~=0
    errordlg('错误！特征组合已改变，必须重新训练','错误提示');
elseif control.CurrentSplitRatioChoice ~= control.PastSplitRatioChoice
    errordlg('错误！训练集验证集比例已改变，必须重新训练','错误提示');
elseif control.CurrentClassifierChoice ~= control.PastClassifierChoice
    errordlg('错误！分类器已改变，必须重新训练','错误提示');
else
    allfts = myfeature(recorder.voice,param.fs);        % 提取各种特征
    voiced = mygetvoiced(recorder.voice,param.fs);      % 把浊音提取出来
    % 根据用户的选择提取特征
    feature = [];
    if get(handles.checkbox_meanpitch,'Value')==1       % 选择了 meanpitch 
        feature = [feature allfts(11)];
    end
    if get(handles.checkbox_maxpitch,'Value')==1       % 选择了 maxpitch 
        feature = [feature allfts(12)];
    end
    if get(handles.checkbox_minpitch,'Value')==1       % 选择了 minpitch 
        feature = [feature allfts(13)];
    end
    if get(handles.checkbox_mfcc,'Value')==1           % 选择了 minpitch 
        feature = [feature allfts(14:26)];
    end
    if get(handles.checkbox_feature1,'Value')==1       % 选择了 feature1 
        LPCC=yourfeature1(voiced,param.fs);
        feature = [feature LPCC(1:10) LPCC(18:27) LPCC(35:44)];
        %feature = [feature myfeature1(voiced,param.fs)];
    end
    if get(handles.checkbox_feature2,'Value')==1       % 选择了 feature2
        feature = [feature myfeature2(voiced,fs)];
    end
    if get(handles.checkbox_feature3,'Value')==1       % 选择了 feature3
        feature = [feature myfeature3(voiced,fs)];
    end
    if get(handles.checkbox_feature4,'Value')==1       % 选择了 feature4
        feature = [feature myfeature4(voiced,fs)];
    end    
    % 判断测试的特征和训练/验证的特征是否一样
    % 判断当前采用的是哪种分类器
    if strcmp(control.classifier,'DistCompare')==1
        if isempty(classifierparam.DCtraincore)
            errordlg('错误！Dist Comapre 分类器不存在,请先训练此分类器','错误提示');
        else
            % DistCompare 检测
            predicted_label = myDistDetermineTest(classifierparam.DCtraincore,feature);
            if predicted_label==1
                set(handles.textCurrentGender,'string','女');
            else
                set(handles.textCurrentGender,'string','男');
            end
        end
    elseif strcmp(control.classifier,'NaiveBayes')==1
        if isempty(classifierparam.NBTrainingSets)||isempty(classifierparam.NBValidationSets)
            errordlg('错误！Naive Bayes 分类器不存在,请先训练此分类器','错误提示');
        else 
            % 首先从 NBTrainingSets 中得出每个特征的最大最小值
            feature_max = max([control.traindata;control.valdata]);
            feature_min = min([control.traindata;control.valdata]);
            % 以此为依据对新特征进行增量量化
            feature_qualify = mydiscretization2(feature_max,feature_min,control.ftsRange,feature);
            % NaiveBayes 检测
            [predicted_label,female_prob,male_prob] = myNaiveBayesTest(classifierparam.NBTrainingSets,feature_qualify);
            if predicted_label==1
                set(handles.textCurrentGender,'string','女');
            else
                set(handles.textCurrentGender,'string','男');
            end
            set(handles.text_PF,'string',num2str(female_prob));
            set(handles.text_PM,'string',num2str(male_prob));
        end
    elseif strcmp(control.classifier,'KMSKNN')==1
        [predicted_label,p]=logistics(feature,classifierparam.Logisic_Reg);
        if predicted_label==1
                set(handles.textCurrentGender,'string','女');
                female_prob=p;
                male_prob=1-p;
        else
                set(handles.textCurrentGender,'string','男');
                male_prob=p;
                female_prob=1-p;
        end
        set(handles.text_PF,'string',num2str(female_prob));
        set(handles.text_PM,'string',num2str(male_prob));
        
    elseif strcmp(control.classifier,'KNN')==1
        if isempty(classifierparam.KNNmodel)
            errordlg('错误！KNN 分类器不存在,请先训练此分类器','错误提示');
        else
            KNN_model = classifierparam.KNNmodel;
            predicted_label = KNN_model.predict(feature);
            if predicted_label==1
                set(handles.textCurrentGender,'string','女');
            else
                set(handles.textCurrentGender,'string','男');
            end
        end
    elseif strcmp(control.classifier,'SVM')==1
        if isempty(classifierparam.SVMmodel)
            errordlg('错误！SVM 分类器不存在,请先训练此分类器','错误提示');
        else
            % 测试
            [predicted_label, ~, ~] = svmpredict(1,feature,classifierparam.SVMmodel);   % 第一个参数"1"是待判断数据的伪标签
            if predicted_label==1
                set(handles.textCurrentGender,'string','女');
            else
                set(handles.textCurrentGender,'string','男');
            end
        end
    else
        errordlg('错误！该分类器不存在','错误提示');
    end
    currentfeature = feature;
    if control.choiceline(1)==1
        set(handles.text_meanpitch,'string',num2str(currentfeature(1)));
        currentfeature(1) = [];
    else
        set(handles.text_meanpitch,'string','——');
    end
    if control.choiceline(2)==1
        set(handles.text_maxpitch,'string',num2str(currentfeature(1)));
        currentfeature(1) = [];
    else
        set(handles.text_maxpitch,'string','——');
    end
    if control.choiceline(3)==1
        set(handles.text_minpitch,'string',num2str(currentfeature(1)));
    else
        set(handles.text_minpitch,'string','——');
    end
    clear currentfeature;